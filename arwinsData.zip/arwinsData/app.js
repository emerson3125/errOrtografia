'use strict'

const express = require('express');
const bodyParser = require('body-parser');

var app = express()

//cargar rutas
var user_routes = require('./routes/user');
var cliente_routes = require('./routes/cliente');
var reunion_routes = require('./routes/reunion')

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

// config cabeceras http

//carga de rutas base
app.use('/api', user_routes);
app.use('/api', cliente_routes);
app.use('/api', reunion_routes);

//test
app.get('/pruebas', (req, res) =>{
    res.status(200).send({"perro" : "hola"})
})

module.exports = app
