'use strict'
require('./connection');

var app = require('./app');
var port = process.env.PORT || 3977;

app.listen(port, _ =>{
    console.log('server on port', port);
});