'use strict'
const fs = require('fs');
const path = require('path');
const Cliente = require('../models/cliente');
const ReunionD = require('../models/detallesR');
const Reunion = require('../models/reunion');
const mongoosePagination = require('mongoose-pagination');

function getReunion(req, res){
    var reunionId = req.params.id;

    Reunion.findById(reunionId).populate({path: 'cliente'}).exec((err, data) =>{
        if(err){
            res.status(500).send({message:'error en la petcion'})
        }else{
            if(!data){
                res.status(404).send({message: "la reunón no existe"})
            }else{
                res.status(200).send({reun: data})
            };
        };
    });
};

function getReuniones(req, res){
    var clienteId = req.params.cliente;

    if(!clienteId){
        //sacar todas las reuniones de la datebase
    }else{
        //sacar las reuniones de un cliente en especifico
    };
};

function saveReunion(req, res){
    var reunion = new Reunion();

    var params = req.body;
    reunion.title = params.title;
    reunion.description = params.description;
    reunion.year = params.year;
    reunion.cliente = params.cliente;

    if(reunion.title != null && reunion.description != null && reunion.year != null && reunion.cliente != null){
        reunion.save((err, data) =>{
            if(err){
                res.status(500).send({message: "error en la peticion"})
            }else{
                if(!data){
                    res.status(404).send({message: "error al guardar la reuinon"})
                }else{
                    res.status(200).send({reun: data})
                };
            };
        });
    };
};

module.exports = {
    getReunion,
    saveReunion
};