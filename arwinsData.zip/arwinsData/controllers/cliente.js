'use strict'
const fs = require('fs');
const path = require('path');
const Cliente = require('../models/cliente');
const ReunionD = require('../models/detallesR');
const Reunion = require('../models/reunion');
const mongoosePagination = require('mongoose-pagination');

function getCliente(req, res){
    var clienteId = req.params.id;

    Cliente.findById(clienteId, (err, data) =>{
        if(err){
            res.status(500).send({message: 'error al encotrar el cliente'});
        }else{
            if(!data){
                res.status(404).send({message: 'cliente no encontrado o no esiste'});
            }else{
                res.status(200).send({cliente: data});
            };
        };
    });
};

function getClientes(req, res){
    if(req.params.page){
        var page = req.params.page;
    }else{
        var page = 1;
    };
    var itemsPerPage = 2;

    Cliente.find().sort('name').paginate(page, itemsPerPage, (err, clientes, total) =>{
        if(err){
            res.status(500).send({message: 'error en la peticion'});
        }else{
            if(!clientes){
                res.status(404).send({message: 'no hay clientes'});
            }else{
                return res.status(200).send({
                    total_items: total,
                    clientes: clientes
                });
            };
        };
    });
};

function saveCliente(req, res){
    var cliente = new Cliente();

    var params = req.body;
    cliente.name = params.name;
    cliente.description = params.description;
    cliente.image = 'null';

    if(cliente.name != null && cliente.description != null){
        cliente.save((err, data) =>{
            if(err){
                res.status(500).send({message: "error al guardar el cliente"});
            }else{
                if(!data){
                    res.status(500).send({message: "error al guardar el cliente, intentelo de nuevo"});
                }else{
                    res.status(200).send({user: data});
                };
            };
        });
    }else{
        res.status(404).send({message: "rellene todo los campos"});
    };
};

function updateCliente(req, res){
    var clienteId = req.params.id;
    var update = req.body;

    Cliente.findByIdAndUpdate(clienteId, update, (err, data) =>{
        if(err){
            res.status(500).send({message: "error en la peticion"});
        }else{
            if(!data){
                res.status(404).send({message: "el cliente no existe"});
            }else{
                res.status(200).send({cliente: data});
            };
        };
    });
};

function deleteCliente(req, res){
    var clienteId = req.params.id;

    Cliente.findByIdAndRemove(clienteId, (err, data) =>{
        if(err){
            res.status(500).send({message: "error en la peticion"});
        }else{
            if(!data){
                res.status(404).send({message: "el cliente no ha sido eliminado"});
            }else{
                Reunion.find({cliente: data._id}).remove((err, reuRemove) =>{
                    if(err){
                        res.status(500).send({message: "error en la peticion"});
                    }else{
                        if(!reuRemove){
                            res.status(404).send({message: "la reunion no ha sido eliminado"});
                        }else{
                            ReunionD.find({reunion: reuRemove._id}).remove((err, reuDRemove) =>{
                                if(err){
                                    res.status(500).send({message: "error en la petision"});
                                }else{
                                    if(!reuDRemove){
                                        res.status(404).send({message: "el detalle no ha sido eliminado"});
                                    }else{
                                        res.status(200).send({clienteR: data});
                                    };    
                                };   
                            });
                        };    
                    };   
                });
            };
        };
    });
};

function uploadImage(req, res){
    var clienteId = req.params.id;
    var file_name = 'No subido...';

    if(req.files){
        var file_path = req.files.image.path;
        var file_split = file_path.split('\\');
        var file_name = file_split[2];

        var ext_split = file_name.split('\.');
        var file_ext = ext_split[1];

        if(file_ext == 'png' || file_ext == 'jpg' || file_ext == 'gif'){
            Cliente.findByIdAndUpdate(clienteId, {image: file_name}, (err, clienteImg) =>{
                if(err){
                    res.status(404).send({message: "imagen no subida..."});
                }else{
                    res.status(200).send({user: clienteImg});
                }
            })
        }else{
            res.status(500).send({message: "la estencion no es correcta"});
        };

        console.log(ext_split);
    }else{
        res.status(404).send({message: "imagen no subida..."});
    };
};

function getImageFile(req, res){
    var imageFile = req.params.imageFile
    var path_file = './uploads/cliente/'+imageFile
    fs.exists(path_file, function(exists){
        if(exists){
            res.sendFile(path.resolve(path_file));
        }else{
            res.status(404).send({message: "imagen no existe..."});
        };
    });
};

module.exports = {
    getCliente,
    saveCliente,
    getClientes,
    updateCliente,
    deleteCliente,
    uploadImage,
    getImageFile
}
