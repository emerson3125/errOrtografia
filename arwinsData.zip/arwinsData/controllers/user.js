'use strict'
const bcrypt = require('bcrypt-nodejs');
const User = require('../models/user');
const jwt = require('../services/jwt');
const fs = require('fs');
const path = require('path');

//test
async function pruebas(req, res){
    res.status(200).send({
        message: "probando una accion perra sarnosa que estas leyendo esto ._."
    });
}

function saveUser(req, res){
    var params = req.body;

    console.log(params);

    var user = new User({
        name: params.name,
        surname: params.surname,
        email: params.email,
        password: params.password,
        role: 'ROLE_ADMIN',
        image: 'null'
    })
    
    if(params.password){
        // encriptar constraseña y guardar datos
        bcrypt.hash(params.password, null, null, (err, hash) =>{
            user.password = hash;
            if(user.name != null && user.surname != null && user.email != null){
                //saved user
                user.save((err, data) =>{
                    if(err){
                        res.status(500).send({message: 'Error al guardar el usuario'})
                    }else{
                        if(!data){
                            res.status(404).send({message: 'no se arregistrado ningun usuario'})
                        }else{
                            res.status(200).send({user: data})
                        }
                    }
                });
            }else{
                res.status(200).send({message: 'introduce los datos completos'})
            }
        });
    }else{
        res.status(500).send({message: 'intruduce la contraseña'});
    }
  
}

function loginUser(req, res){
    var params = req.body;

    var email = params.email;
    var password = params.password;

    User.findOne({email : email.toLowerCase()}, (err, user) =>{
        if(err){
            res.status(500).send({message: 'error en la petición'})
        }else{
            if(!user){
                res.status(404).send({message: 'no se a encotrado ningun usuario'})
            }else{
                //comparar la contraseña
                bcrypt.compare(password, user.password, (err, check) =>{
                    if(check){
                        //dovolver datos del user
                        if(params.gethash){
                            // devolver un token jwt
                            res.status(200).send({
                                token: jwt.createToken(user)
                            })
                        }else{
                            res.status(200).send({user})
                        }
                    }else{
                        res.status(404).send({message: 'el usuario no a podido logearse'})
                    }
                });
            }
        }
    });
}

function updateUser(req, res){
    var userId = req.params.id;
    var update = req.body;

    User.findByIdAndUpdate(userId, update, (err, user) =>{
        if(err){
            res.status(500).send({message: 'error al actualizar ul usuario'})
        }else{
            if(!user){
                res.status(404).send({message: 'No se ha podido actualizar el usuario'})
            }else{
                res.status(200).send({user: user})
            }
        }
    });
}

function uploadImage(req, res){
    var userId = req.params.id;
    var file_name = 'No subido...';

    if(req.files){
        var file_path = req.files.image.path;
        var file_split = file_path.split('\\');
        var file_name = file_split[2];

        var ext_split = file_name.split('\.');
        var file_ext = ext_split[1];

        if(file_ext == 'png' || file_ext == 'jpg' || file_ext == 'gif'){
            User.findByIdAndUpdate(userId, {image: file_name}, (err, userImg) =>{
                if(err){
                    res.status(404).send({message: "imagen no subida..."});
                }else{
                    res.status(200).send({user: userImg});
                }
            })
        }else{
            res.status(500).send({message: "la extencion no es correcta"});
        };

        console.log(ext_split);
    }else{
        res.status(404).send({message: "imagen no subida..."});
    };
};

function getImageFile(req, res){
    var imageFile = req.params.imageFile
    var path_file = './uploads/users/'+imageFile
    fs.exists(path_file, function(exists){
        if(exists){
            res.sendFile(path.resolve(path_file));
        }else{
            res.status(404).send({message: "imagen no existe..."});
        };
    });
};

module.exports = {
    pruebas, 
    saveUser, 
    loginUser,
    updateUser,
    uploadImage,
    getImageFile
};