'use strict'

const express = require('express');
const server = express.Router();
const ReunionController = require('../controllers/reunion');
const md_autorizacion = require('../middelwares/authenticated');
var multipart = require('connect-multiparty');
var md_upload = multipart({ uploadDir: './uploads/reunion' });

//dona estas son las rutas no las vayas a modificar
server.get('/getReunion/:id', md_autorizacion.ensureAuth,ReunionController.getReunion);
server.post('/addReunion', md_autorizacion.ensureAuth,ReunionController.saveReunion);

module.exports = server;