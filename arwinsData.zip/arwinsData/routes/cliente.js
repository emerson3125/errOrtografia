'use strict'

const express = require('express');
const server = express.Router();
const ClienteController = require('../controllers/cliente');
const md_autorizacion = require('../middelwares/authenticated');
var multipart = require('connect-multiparty');
var md_upload = multipart({ uploadDir: './uploads/cliente' });

//dona estas son las rutas no las vayas a modificar
server.get('/cliente/:id', md_autorizacion.ensureAuth, ClienteController.getCliente);
server.get('/clientes/:page?', md_autorizacion.ensureAuth, ClienteController.getClientes);
server.post('/addCliente', md_autorizacion.ensureAuth, ClienteController.saveCliente);
server.put('/updateCliente/:id', md_autorizacion.ensureAuth, ClienteController.updateCliente);
server.delete('/deleteCliente/:id', md_autorizacion.ensureAuth, ClienteController.deleteCliente);
server.post('/imageCliente/:id', [md_autorizacion.ensureAuth, md_upload], ClienteController.uploadImage);
server.get('/getImageClient/:imageFile', ClienteController.getImageFile);


module.exports = server;