'use strict'

const express = require('express');
const UserController = require('../controllers/user');
const md_autorizacion = require('../middelwares/authenticated');
const api = express.Router();
var multipart = require('connect-multiparty');
var md_upload = multipart({ uploadDir: './uploads/users' });

//dona estas son las rutas no las vayas a modificar
api.get('/test', md_autorizacion.ensureAuth, UserController.pruebas);
api.post('/addUser',md_autorizacion.ensureAuth, UserController.saveUser);
api.post('/loginUser', UserController.loginUser);
api.put('/updateUser/:id', md_autorizacion.ensureAuth, UserController.updateUser);
api.post('/imageUser/:id', [md_autorizacion.ensureAuth, md_upload], UserController.uploadImage);
api.get('/getImageUser/:imageFile', UserController.getImageFile);

module.exports = api;