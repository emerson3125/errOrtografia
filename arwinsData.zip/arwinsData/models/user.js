'use strict'
var {Schema, model} = require('mongoose');

var UserSchema = new Schema({
    name: String,
    surname: String,
    email: String,
    password: String,
    role: String,
    image: String 
});

module.exports = model('user', UserSchema)