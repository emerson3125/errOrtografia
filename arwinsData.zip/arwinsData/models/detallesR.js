'use strict'
var {Schema, model} = require('mongoose');

var DetallesSchema = new Schema({
    number: Number,
    name: String,
    dura: Number,
    image: String,
    reunion: {
        type: Schema.ObjectId, ref: 'Reunion'
    }
});

module.exports = model('Detalle', DetallesSchema)