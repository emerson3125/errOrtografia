'use strict'
var {Schema, model} = require('mongoose');

var ClienteSchema = new Schema({
    name: String,
    description: String,
    image: String 
});

module.exports = model('Cliente', ClienteSchema)