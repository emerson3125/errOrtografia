'use strict'
var {Schema, model} = require('mongoose');

var ReunionteSchema = new Schema({
    title: String,
    description: String,
    year: Number,
    cliente: {
        type: Schema.ObjectId, ref: 'Cliente'
    }
});

module.exports = model('Reunion', ReunionteSchema)